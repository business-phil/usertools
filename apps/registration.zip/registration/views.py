from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User

def index(request):
    request.session.clear()
    return render(request, 'registration/index.html')

def view(request):
    if 'user_id' in request.session:
        user_query = User.objects.get(id=request.session['user_id'])
        context = { 'user': user_query }
        return render(request, 'registration/view.html', context)
    else:
        return redirect('/users/')

def create(request):
    regstatus = User.userManager.register(**request.POST)
    if regstatus[0]:
        messages.success(request, 'You have successfully registered!')
        request.session['user_id'] = regstatus[1]
        return redirect('/users/view')
    else:
        for message in regstatus[1]:
            messages.warning(request, message)
        return redirect('/users/')

def login(request):
    loginstatus = User.userManager.login(request.POST['email'], request.POST['password'])
    if loginstatus[0]:
        request.session['user_id'] = loginstatus[1]
        return redirect('/users/view')
    else:
        messages.warning(request, loginstatus[1])
        return redirect('/users/')
